Intel MEI / TEE driver experimental Windows 7 x64 package
============================================================

Basis:
- Original Intel driver version: 1914.12.0.1256 (2019-04-04)
- INF targets Windows 7 x64 (NTamd64.6.1)
- KMDF version declared by INF: 1.11
- Original TeeDriverx64.sys left byte-for-byte unchanged
- Added hardware ID: PCI\VEN_8086&DEV_06E0

IMPORTANT:
This is an experimental hardware-ID INF adaptation, NOT a proven driver
port. The binary's imports are compatible with the Windows 7-era kernel
surface examined, and it does not import PoFx APIs. That does not prove
that its firmware protocol supports this newer MEI device.

The Intel catalog was intentionally not included because modifying the INF
invalidates the original catalog signature. Windows 7 x64 may refuse the
package unless driver-signature enforcement is disabled for that boot.
Do not disable security features permanently just to force installation.

Test only on the backup VHD. Do not replace files in the DriverStore
manually. If Windows rejects the package, stop and report the exact error.
If it installs but the device fails to start, collect Device Manager status
and setupapi.dev.log before attempting any further changes.
